/*******************************************************************************
 ************************* QQ858860583 *****************************************
 ************************* ����ԭ����̳�ţ�cornrn ******************************	
 *******************************************************************************/
#ifndef _LCD5110_H
#define _LCD5110_H
#include "board_init.h" 

/******************************�������� ******************************/
#define LCD_X_RES		84
#define LCD_Y_RES		48 
/**************************ö�� D/Cģʽѡ�� **************************/
typedef enum
{
  DC_CMD  = 0,	//д����
	DC_DATA = 1		//д����	
} DCType;
/**********************�ܽ����� H: high, L: low***********************/
#define LCD_CTRL_PORT	GPIOD
#define LCD_RST			  GPIO_PIN_7
#define LCD_CE			  GPIO_PIN_5
#define LCD_DC			  GPIO_PIN_14

 
/***************************config as spi2 ***************************/

#define LCD_CLK			  GPIO_PIN_4
#define LCD_MOSI		  GPIO_PIN_6

#define LCD_RST_H()		GPIO_SetBits  (LCD_CTRL_PORT, LCD_RST)
#define LCD_RST_L()		GPIO_ClearBits(LCD_CTRL_PORT, LCD_RST)
#define LCD_CE_H()		GPIO_SetBits  (LCD_CTRL_PORT, LCD_CE)
#define LCD_CE_L()		GPIO_ClearBits(LCD_CTRL_PORT, LCD_CE)
#define LCD_DC_DATA()	GPIO_SetBits  (LCD_CTRL_PORT, LCD_DC)
#define LCD_DC_CMD()	GPIO_ClearBits(LCD_CTRL_PORT, LCD_DC)
#define LCD_MOSI_H()	GPIO_SetBits  (LCD_CTRL_PORT, LCD_MOSI)
#define LCD_MOSI_L()	GPIO_ClearBits(LCD_CTRL_PORT, LCD_MOSI)
#define LCD_CLK_H()		GPIO_SetBits  (LCD_CTRL_PORT, LCD_CLK)
#define LCD_CLK_L()		GPIO_ClearBits(LCD_CTRL_PORT, LCD_CLK)
 

/************************��������****************************/

void LCD5110_Init(void);
void LCD_Clear(void);
void LCD_SetXY(uint8_t X, uint8_t Y);
void LCD_SetContrast(uint8_t contrast);
void LCD_Send(uint8_t data, DCType dc);
void LCD_Write_Char(uint8_t ascii);
void LCD_Write_EnStr(uint8_t X, uint8_t Y, uint8_t* s);
void LCD_Write_Hanzi(uint8_t X, uint8_t Y,uint8_t GBK);
void LCD5110_IO_Configuration(void);

#define puts_xy(x,y,s) LCD_Write_EnStr(x, y, s)
#endif

